from django.contrib import admin
from .models import Marca, CategoriaInstrumento, Instrumento, Pedido

admin.site.register(Marca)
admin.site.register(CategoriaInstrumento)
admin.site.register(Instrumento)
admin.site.register(Pedido)
