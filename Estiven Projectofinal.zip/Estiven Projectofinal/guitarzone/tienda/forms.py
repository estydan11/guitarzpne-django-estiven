from django import forms
from .models import Marca, CategoriaInstrumento, Instrumento, Pedido


class MarcaForm(forms.ModelForm):
    class Meta:
        model = Marca
        fields = ['nombre', 'pais_origen']


class CategoriaInstrumentoForm(forms.ModelForm):
    class Meta:
        model = CategoriaInstrumento
        fields = ['nombre', 'descripcion']


class InstrumentoForm(forms.ModelForm):
    class Meta:
        model = Instrumento
        fields = ['nombre', 'precio', 'stock', 'marca', 'categoria']


class PedidoForm(forms.ModelForm):
    class Meta:
        model = Pedido
        fields = ['cliente', 'fecha', 'instrumento', 'cantidad', 'estado']
