from django.shortcuts import render, redirect, get_object_or_404
from .models import Marca, CategoriaInstrumento, Instrumento, Pedido
from .forms import MarcaForm, CategoriaInstrumentoForm, InstrumentoForm, PedidoForm


def home(request):
    return render(request, 'tienda/home.html')


# ---------------- MARCAS ----------------

def marca_list(request):
    marcas = Marca.objects.all()
    return render(request, 'tienda/marca_list.html', {'marcas': marcas})


def marca_create(request):
    if request.method == 'POST':
        form = MarcaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('marca_list')
    else:
        form = MarcaForm()
    return render(request, 'tienda/marca_form.html', {'form': form})


def marca_update(request, pk):
    marca = get_object_or_404(Marca, pk=pk)
    if request.method == 'POST':
        form = MarcaForm(request.POST, instance=marca)
        if form.is_valid():
            form.save()
            return redirect('marca_list')
    else:
        form = MarcaForm(instance=marca)
    return render(request, 'tienda/marca_form.html', {'form': form})


def marca_delete(request, pk):
    marca = get_object_or_404(Marca, pk=pk)
    if request.method == 'POST':
        marca.delete()
        return redirect('marca_list')
    return render(request, 'tienda/marca_confirm_delete.html', {'marca': marca})


# ---------------- CATEGORÍAS ----------------

def categoria_list(request):
    categorias = CategoriaInstrumento.objects.all()
    return render(request, 'tienda/categoria_list.html', {'categorias': categorias})


def categoria_create(request):
    if request.method == 'POST':
        form = CategoriaInstrumentoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('categoria_list')
    else:
        form = CategoriaInstrumentoForm()
    return render(request, 'tienda/categoria_form.html', {'form': form})


def categoria_update(request, pk):
    categoria = get_object_or_404(CategoriaInstrumento, pk=pk)
    if request.method == 'POST':
        form = CategoriaInstrumentoForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            return redirect('categoria_list')
    else:
        form = CategoriaInstrumentoForm(instance=categoria)
    return render(request, 'tienda/categoria_form.html', {'form': form})


def categoria_delete(request, pk):
    categoria = get_object_or_404(CategoriaInstrumento, pk=pk)
    if request.method == 'POST':
        categoria.delete()
        return redirect('categoria_list')
    return render(request, 'tienda/categoria_confirm_delete.html', {'categoria': categoria})


# ---------------- INSTRUMENTOS ----------------

def instrumento_list(request):
    instrumentos = Instrumento.objects.all()
    return render(request, 'tienda/instrumento_list.html', {'instrumentos': instrumentos})


def instrumento_create(request):
    if request.method == 'POST':
        form = InstrumentoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('instrumento_list')
    else:
        form = InstrumentoForm()
    return render(request, 'tienda/instrumento_form.html', {'form': form})


def instrumento_update(request, pk):
    instrumento = get_object_or_404(Instrumento, pk=pk)
    if request.method == 'POST':
        form = InstrumentoForm(request.POST, instance=instrumento)
        if form.is_valid():
            form.save()
            return redirect('instrumento_list')
    else:
        form = InstrumentoForm(instance=instrumento)
    return render(request, 'tienda/instrumento_form.html', {'form': form})


def instrumento_delete(request, pk):
    instrumento = get_object_or_404(Instrumento, pk=pk)
    if request.method == 'POST':
        instrumento.delete()
        return redirect('instrumento_list')
    return render(request, 'tienda/instrumento_confirm_delete.html', {'instrumento': instrumento})


# ---------------- PEDIDOS ----------------

def pedido_list(request):
    pedidos = Pedido.objects.all()
    return render(request, 'tienda/pedido_list.html', {'pedidos': pedidos})


def pedido_create(request):
    if request.method == 'POST':
        form = PedidoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('pedido_list')
    else:
        form = PedidoForm()
    return render(request, 'tienda/pedido_form.html', {'form': form})


def pedido_update(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    if request.method == 'POST':
        form = PedidoForm(request.POST, instance=pedido)
        if form.is_valid():
            form.save()
            return redirect('pedido_list')
    else:
        form = PedidoForm(instance=pedido)
    return render(request, 'tienda/pedido_form.html', {'form': form})


def pedido_delete(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    if request.method == 'POST':
        pedido.delete()
        return redirect('pedido_list')
    return render(request, 'tienda/pedido_confirm_delete.html', {'pedido': pedido})

