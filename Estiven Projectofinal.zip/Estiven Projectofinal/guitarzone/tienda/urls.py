from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    # Marcas
    path('marcas/', views.marca_list, name='marca_list'),
    path('marcas/nueva/', views.marca_create, name='marca_create'),
    path('marcas/editar/<int:pk>/', views.marca_update, name='marca_update'),
    path('marcas/eliminar/<int:pk>/', views.marca_delete, name='marca_delete'),

    # Categorías
    path('categorias/', views.categoria_list, name='categoria_list'),
    path('categorias/nueva/', views.categoria_create, name='categoria_create'),
    path('categorias/editar/<int:pk>/', views.categoria_update, name='categoria_update'),
    path('categorias/eliminar/<int:pk>/', views.categoria_delete, name='categoria_delete'),

    # Instrumentos
    path('instrumentos/', views.instrumento_list, name='instrumento_list'),
    path('instrumentos/nuevo/', views.instrumento_create, name='instrumento_create'),
    path('instrumentos/editar/<int:pk>/', views.instrumento_update, name='instrumento_update'),
    path('instrumentos/eliminar/<int:pk>/', views.instrumento_delete, name='instrumento_delete'),

    # Pedidos
    path('pedidos/', views.pedido_list, name='pedido_list'),
    path('pedidos/nuevo/', views.pedido_create, name='pedido_create'),
    path('pedidos/editar/<int:pk>/', views.pedido_update, name='pedido_update'),
    path('pedidos/eliminar/<int:pk>/', views.pedido_delete, name='pedido_delete'),
]
